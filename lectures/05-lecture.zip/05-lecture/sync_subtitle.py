def shift_timing(time_str, delta):
    hours, minutes, seconds = time_str.split(':')
    seconds, millisecond = seconds.split(',')

    hours = int(hours)
    minutes = int(minutes)
    seconds = int(seconds)
    millisecond = int(millisecond)

    seconds += delta

    minutes += seconds//60
    seconds %= 60

    hours += minutes//60
    minutes %= 60

    shifted_time = '{:02d}:{:02d}:{:02d},{:03d}'.format(hours,
                                                        minutes,
                                                        seconds,
                                                        millisecond)

    return shifted_time


def shift_quote(quote, delta):
    quote_lines = quote.split('\n')
    start_time, end_time = quote_lines[1].split(' --> ')

    shifted_start_time = shift_timing(start_time, delta)
    shifted_end_time   = shift_timing(end_time, delta)
    shifted_timing = shifted_start_time + ' --> ' + shifted_end_time

    quote_lines[1] = shifted_timing

    shifted_quote = '\n'.join(quote_lines)

    return shifted_quote


def shift_str_file(filename, delta):
    with open(filename, 'r') as f:
        content = f.read()

    quotes = content.split('\n\n')

    shifted_quotes = []
    for quote in quotes[:-1]:
        shifted_quotes.append(shift_quote(quote, delta))

    shifted_content = '\n\n'.join(shifted_quotes)
    shifted_content += '\n\n'

    shifted_filename = 'SHIFTED-' + str(delta) + '-' + filename

    with open(shifted_filename, 'w') as f:
        f.write(shifted_content)


def main():
    print('Welcom to the Subtitles Synchronizer!')
    filename = input('Enter str filename path: ')
    delta = int(input('Enter delta in seconds (whole number): '))
    print('Syncing...')
    shift_str_file(filename, delta)
    print('Done!')


if __name__ == '__main__':
    main()
