# Image Editor Solution - Reading Code - Task
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# You can find in this program a question as comments
# regarding its design and code.
# Answer them by order (Q1, Q2, Q3, ...),
# which server as guidance for the code reading.
# Write your answer as comments in this file, in a text file or on a paper.
# After you finish to answer all the question, fill this short form:
# https://shlomihod.typeform.com/to/fkzk8c


PPM_HEADER = """P3
{columns} {rows}
255
"""

PPM_PIXEL_STRING = "{:3} {:3} {:3}"

TRANSFORM_OPTIONS_MENU = """
Here are your choices:
    [1]  convert to greyscale [2]  flip horizontally
    [3]  negative of red [4]  negative of green [5]  negative of blue
    [6]  just the reds   [7]  just the greens   [8]  just the blues
"""


def negate(pixels, color_index):
    transformed_pixels = []
    for pixel in pixels:
        transformed_pixel = pixel[:]
        transformed_pixel[color_index] = 255 - transformed_pixel[color_index]
        transformed_pixels.append(transformed_pixel)
    return transformed_pixels


def negate_red(pixels):
    """negate the red number of each pixel."""
    return negate(pixels, 0)


def negate_green(pixels):
    """negate the green number of each pixel."""
    return negate(pixels, 1)


def negate_blue(pixels):
    """negate the blue number of each pixel."""
    return negate(pixels, 2)


def flip_horizontal(pixels):
    """flip each row horizontally."""
    return pixels[::-1]


def grey_scale(pixels):
    """sets each pixel value to the average of the three."""

    transformed_pixels = []

    for pixel in pixels:
        gray_scale_value = int(sum(pixel) / 3)
        transformed_pixels.append([gray_scale_value,
                                   gray_scale_value,
                                   gray_scale_value])

    return transformed_pixels


def flatten(pixels, color_index):
    transformed_pixels = []
    for pixel in pixels:
        transformed_pixel = pixel[:]
        transformed_pixel[color_index] = 0
        transformed_pixels.append(transformed_pixel)
    return transformed_pixels


def flatten_red(pixels):
    """sets the red value to zero."""
    return flatten(pixels, 0)


def flatten_green(pixels):
    """sets the green value to zero."""
    return flatten(pixels, 1)


def flatten_blue(pixels):
    """sets the blue value to zero."""
    return flatten(pixels, 2)


def keep_just_red(pixels):
    return flatten_blue(flatten_green(pixels))


def keep_just_green(pixels):
    return flatten_blue(flatten_red(pixels))


def keep_just_blue(pixels):
    return flatten_red(flatten_green(pixels))


def load_header(image_file):
    image_file.readline()
    columns, rows = [int(value) for value in image_file.readline().split()]
    image_file.readline()
    return columns, rows


def save_header(image_file, columns, rows):
    image_file.write(PPM_HEADER.format(
        columns=columns,
        rows=rows))


def line2pixels(line):
    line_values = [int(value) for value in line.split()]
    pixels = [line_values[pixel_index:pixel_index + 3]
              for pixel_index in range(0, len(line_values), 3)]
    return pixels


def pixels2line(pixels):
    pixel_strings = [PPM_PIXEL_STRING.format(pixel[0], pixel[1], pixel[2])
                     for pixel in pixels]
    line = "  ".join(pixel_strings) + "\n"
    return line


def prompt_for_transformations():
    transforms = [
        grey_scale,
        flip_horizontal,
        negate_red,
        negate_blue,
        negate_green,
        keep_just_red,
        keep_just_green,
        keep_just_blue,
    ]
    print(TRANSFORM_OPTIONS_MENU)
    responses = [
        input("Do you want [{}]? (y/n) ".format(option_index))
        for option_index in range(1, len(transforms) + 1)
    ]
    return [func for func, resp in zip(transforms, responses) if resp == "y"]


def apply(chosen_transforms, pixels):
    for transform in chosen_transforms:
        pixels = transform(pixels)
    return pixels


def main():
    print("Portable Pixmap (PPM) Image Editor!")

    input_path = input("Enter name of image file: ")
    output_path = input("Enter name of output file: ")

    with open(input_path) as input_file, open(output_path, 'w') as output_file:
        # Q1: What are the functions load_header and save_header doing?
        # Q2: Write a decent docstring for these two functions.
        columns, rows = load_header(input_file)
        save_header(output_file, columns, rows)

        # Q3: What is the use of the TRANSFORM_OPTIONS_MENU variable?
        chosen_transforms = prompt_for_transformations()

        # Assumption: We are limited to process one row of pixels every time
        current_pixels = []

        # Q4: What is input_line iterating over?
        for input_line in input_file:

            # Q5: Write a decent docstring for the function line2pixels
            input_pixels = line2pixels(input_line)

            # Q6: What is current_pixels used for?
            current_pixels.extend(input_pixels)

            # Q7: Why are the transformations applied only when
            # len(current_pixels) == columns is True?

            # Assumption: one pixel row will always be on
            # whole successive file lines.
            if len(current_pixels) == columns:
                # Q10: What is chosen_transforms? What is used for?
                # When and how is it created?

                # Q11: Write a decent docstring for the function apply
                pixels = apply(chosen_transforms, current_pixels)

                # Q9: Write a decent docstring for the function pixels2line
                output_line = pixels2line(pixels)
                output_file.write(output_line)

                # Q8: Why is current_pixels set to an empty list inside this if block?
                current_pixels = []
    print(output_path, "created.")


if __name__ == '__main__':
    main()
