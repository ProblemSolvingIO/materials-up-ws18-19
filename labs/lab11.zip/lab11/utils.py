import timeit

import matplotlib.pylab as plt


def plot_ld_runtime(ld_func, seq1, seq2, figsize=(10, 10)):

	assert len(seq1) == len(seq2)

	timing = []
	lengths = range(1, len(seq1))

	for length in lengths:
	    at_length_seq1 = seq1[:length]
	    at_length_seq2 = seq2[:length]
	    
	    at_length_timing = timeit.timeit('ld_func(at_length_seq1, at_length_seq2)',
	                                     number=10, globals=locals())
	    
	    timing.append(at_length_timing)

	f, ax = plt.subplots(1, figsize=figsize)

	plt.plot(lengths, timing)
	
	plt.xlabel('Sequence length')
	plt.xlabel('Seconds')
	plt.title('Recursive Levinstein Distance Running Time per Sequence Length')
	plt.yscale('log')

	return ax