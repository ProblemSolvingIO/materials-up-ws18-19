test = {
  'name': 'phase-2-checklist',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> callable(negate_red)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> callable(negate_green)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> callable(negate_blue)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> callable(flip_horizontal)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> callable(grey_scale)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> callable(flatten_red)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> callable(flatten_green)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> callable(flatten_blue)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from image_editor import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
