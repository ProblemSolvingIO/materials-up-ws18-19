# YOUR CODE HERE


def main():
    # YOUR CODE HERE


# Don't change this part;
# and don't write code outside functions
if __name__ == '__main__':
    main()