def unicode_codes(s):
    """
    Return a list of the Unicode code of each character in a given string `s`.

    Hint: Use the Python builtin function `ord`.
    https://docs.python.org/3/library/functions.html#ord

    >>> full_alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    >>> unicode_codes(full_alphabet) == [97, 98, 99, 100, 101, 102, 103, 104, 105,
    ...                                 106, 107, 108, 109, 110, 111, 112, 113, 114,
    ...                                 115, 116, 117, 118, 119, 120, 121, 122, 65, 66,
    ...                                 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78,
    ...                                 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90]
    True
    """

    # YOUR CODE HERE
    pass


def digits_sum(number):
    """
    Takes a number and returns the sum of its digits.

    >>> digits_sum(1)
    1

    >>> digits_sum(12)
    3
    
    >>> digits_sum(404)
    8
    
    >>> digits_sum(49)
    13
    
    >>> digits_sum(192837465)
    45
    """
    
    # YOUR CODE HERE
    pass


def build_temperature_table(start, end, step):
    """
    Create a temperature table.
    
    Returns a list of tuples; each tuple has two values,
    a temperature in Celsius and a temperature in Farenheit.

    The function takes the `start` of the Celsius temperature values,
    the `end of the Celsius temperature values,
    and the `step` between each two adjunct Celsius temperature values.

    >>> build_temperature_table(0, 10, 3) == [(0, 32.0), (3, 37.4), (6, 42.8), (9, 48.2)]
    True

    >>> build_temperature_table(-5, 5, 1) == [(-5, 23.0), (-4, 24.8), (-3, 26.6), (-2, 28.4),
    ...                                       (-1, 30.2), (0, 32.0), (1, 33.8), (2, 35.6), (3, 37.4),
    ...                                       (4, 39.2)]
    True

    >>> build_temperature_table(-1, 6, 2) == [(-1, 30.2), (1, 33.8), (3, 37.4), (5, 41.0)]
    True
    """

    # YOUR CODE HERE
    pass


def calc_std(numbers):
    """
    Take a list of numbers and return their standard deviation.

    >>> round(calc_std(range(10)), 2)
    2.87
    >>> round(calc_std(range(1000)), 2)
    288.67
    """
    
    # YOUR CODE HERE
    pass


def longer_than(length, strings):
    """
    Takes a list of strings and a minimum length (number)
    and returns only the strings that are longer than the provided number.

    >>> longer_than(3, ["x", "xx", "xxx", "xxxx", "xxxxx"])
    ['xxxx', 'xxxxx']

    >>> longer_than(3, ['hit', 'me', 'baby', 'one', 'more', 'time'])
    ['baby', 'more', 'time']
    
    >>> longer_than(4, ['Because', "I'm", 'easy', 'come,', 'easy', 'go', 'A', 'little', 'high,', 'little', 'low'])
    ['Because', 'come,', 'little', 'high,', 'little']
    """
    
    # YOUR CODE HERE
    pass


def match_ends(words):
    """
    Given a list of strings, return the count of the number of
    strings where the string length is 2 or more and the first
    and last chars of the string are the same.
    (Credit: Google Python Class)

    >>> match_ends(['aba', 'xyz', 'aa', 'x', 'bbb'])
    2
    >>> match_ends(['', 'x', 'xy', 'xyx', 'xx'])
    1
    >>> match_ends(['aaa', 'be', 'abc', 'hello'])
    1
    """
    
    # YOUR CODE HERE
    pass


def front_x(words):
    """
    Given a list of strings, return a list with the strings
    in sorted order, except group all the strings that begin with 'x' first.
    (Credit: Google Python Class)

    >>> front_x(['bbb', 'ccc', 'axx', 'xzz', 'xaa'])
    ['xaa', 'xzz', 'axx', 'bbb', 'ccc']
    >>> front_x(['ccc', 'bbb', 'aaa', 'xcc', 'xaa'])
    ['xaa', 'xcc', 'aaa', 'bbb', 'ccc']
    >>> front_x(['mix', 'xyz', 'apple', 'xanadu', 'aardvark'])
    ['xanadu', 'xyz', 'aardvark', 'apple', 'mix']
    """
  
    # YOUR CODE HERE
    pass


# ROT13 is a weak form of encryption
# that involves “rotating” each letter in a word by 13 places.
# To rotate a letter means to shift it through the alphabet,
# wrapping around to the beginning if necessary,
# so `a` shifted by `3` is `d` and `z` shifted by `1` is `a`.

def rotate_word(s, rotation):
    """
    Takes a string and an integer as parameters,
    and that returns a new string that contains the letters
    from the original string “rotated” by the given amount.
    All the letters are in lower case.

    >>> rotate_word('cheer', 7)
    'jolly'

    >>> rotate_word('lala kahle', 0)
    'lala kahle'

    >>> rotate_word('melon', -10)
    'cubed'
    
    >>> rotate_word('ulhy aol cpsshnl aol wlhjlmbs cpsshnl aol spvu zsllwz avupnoa', 19)
    'near the village the peaceful village the lion sleeps tonight'

    >>> rotate_word('va gur whatyr gur zvtugl whatyr gur yvba fyrrcf gbavtug', 13)
    'in the jungle the mighty jungle the lion sleeps tonight'

    >>> rotate_word('jwuj oa fctnkpi fqpv hgct oa fctnkpi vjg nkqp unggru vqpkijv', 24)
    'hush my darling dont fear my darling the lion sleeps tonight'
    """
    
    # YOUR CODE HERE
    pass


def all_dice_combinations():
    """
    Returns a single list with all 36 different dice combinations from (1,1) to (6,6).

    >>> all_dice_combinations() == [(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6),
    ...                             (2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 6),
    ...                             (3, 1), (3, 2), (3, 3), (3, 4), (3, 5), (3, 6),
    ...                             (4, 1), (4, 2), (4, 3), (4, 4), (4, 5), (4, 6),
    ...                             (5, 1), (5, 2), (5, 3), (5, 4), (5, 5), (5, 6),
    ...                             (6, 1), (6, 2), (6, 3), (6, 4), (6, 5), (6, 6)]
    True
    """
    
    # YOUR CODE HERE
    pass


def groupby(func, lst):
    """
    Group-by object by the result of a function.
    Takes a key-function and a list.
    The function call key-function on each item in the list
    and return a dictionary whose keys are the results of key-function
    and values are all values from the list that produced that key.

    Note: The code does not need to be efficient.

    >>> def get_first(seq):
    ...     return seq[0]

    >>> groups1 = groupby(get_first, ['hello', 'hi', 'help', 'bye', 'here'])
    >>> groups1 ==  {'b': ['bye'], 'h': ['hello', 'hi', 'help', 'here']}
    True

    >>> groups2 = groupby(get_first, ['slippery', 'lackadaisical',
    ...                               'quilt', 'cattle', 'slow', 'true',
    ...                               'black', 'pickle', 'shiver', 'magical',
    ...                               'crow', 'alike', 'knowledge', 'crack', 'claim', 'succeed'])
    >>> groups2 == {'b': ['black'],
    ...             't': ['true'], 'c': ['cattle', 'crow', 'crack', 'claim'],
    ...             'a': ['alike'],
    ...             's': ['slippery', 'slow', 'shiver', 'succeed'],
    ...             'k': ['knowledge'],
    ...             'l': ['lackadaisical'],
    ...             'p': ['pickle'],
    ...             'm': ['magical'],
    ...             'q': ['quilt']}
    True
    
    >>> def get_last(seq):
    ...     return seq[-1]

    >>> groups3 = groupby(get_last, ['slippery', 'lackadaisical',
    ...                              'quilt', 'cattle', 'slow', 'true',
    ...                              'black', 'pickle', 'shiver', 'magical',
    ...                              'crow', 'alike', 'knowledge', 'crack',
    ...                              'claim', 'succeed'])
    >>> groups3 == {'d': ['succeed'],
    ...             'e': ['cattle', 'true', 'pickle', 'alike', 'knowledge'],
    ...             'k': ['black', 'crack'],
    ...             'l': ['lackadaisical', 'magical'],
    ...             'm': ['claim'],
    ...             'r': ['shiver'],
    ...             't': ['quilt'],
    ...             'w': ['slow', 'crow'],
    ...             'y': ['slippery']}
    True
    """
    
    # YOUR CODE HERE
    pass

