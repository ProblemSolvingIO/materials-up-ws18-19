"""Counts the number of syllables from command-line input.

To run, open up a terminal, change do the folder containing this file.
Then type in the following command, making sure to replace the last
part with some word that comes to mind:

```
python count_syllables.py <TYPE_SOME_WORD>
```
"""
import sys


def count_syllables(word):
    vowels = "aeiou"
    n_vowels = 0
    for char in word:
        if char in vowels:
            n_vowels = n_vowels + 1
    return n_vowels


print(count_syllables(input("Please enter a word then hit <Enter>: ")))
