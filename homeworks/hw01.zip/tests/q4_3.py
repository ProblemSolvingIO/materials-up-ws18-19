test = {
  'name': 'Question 4.3',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type_token_ratio(['life'])
          1.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> type_token_ratio(['to', 'be', 'or', 'not', 'to', 'be', 'that', 'is', 'the', 'question'])
          0.8
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> type_token_ratio(['alice', 'how', 'long', 'is', 'forever', 'white', 'rabbit', 'sometimes', 'just', 'one', 'second'])
          1.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> 0.065 < type_token_ratio(emma_words) < 0.066
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
