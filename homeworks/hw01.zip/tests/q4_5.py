test = {
  'name': 'Question 4.5',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> compare_signatures([1, 2, 3], [3, 2, 1], [0, 1, 5])
          10
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> compare_signatures([1, 0, 0], [2, 4, 7], [3, 5, 6])
          65
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> compare_signatures([0, 1, 0], [2, 4, 7], [3, 5, 6])
          63
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> compare_signatures([0, 0, 1], [2, 4, 7], [3, 5, 6])
          62
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> 1.13 < compare_signatures(emma_features, jane_austen_signature, [11, 33, 50]) < 1.14
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
