test = {
  'name': 'Question 4.6',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> score, author = find_likeliest_author('mysteries/mystery1.txt')
          >>> author
          'jane austen'
          >>> 1.131 < score < 1.132
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
