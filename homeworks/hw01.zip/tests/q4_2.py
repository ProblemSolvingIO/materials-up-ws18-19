test = {
  'name': 'Question 4.2',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> average_word_length(['life'])
          4.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> average_word_length(['to', 'be', 'or', 'not', 'to', 'be', 'that', 'is', 'the', 'question'])
          3.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> 4.9 < average_word_length(['alice', 'how', 'long', 'is', 'forever', 'white', 'rabbit', 'sometimes', 'just', 'one', 'second']) < 5
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> 4.425 < average_word_length(emma_words) < 4.426
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
