test = {
  'name': 'Question 4.1',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> text2words('To be, or not to be: that is the question!')
          ['to', 'be', 'or', 'not', 'to', 'be', 'that', 'is', 'the', 'question']
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> text2words('Who? What?! Are... you... sure? (yes, I am quite sure...')
          ['who', 'what', 'are', 'you', 'sure', 'yes', 'i', 'am', 'quite', 'sure']
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> text2words('"Alice: "How long is forever?"\nWhite Rabbit: "Sometimes, just one second."')
          ['alice', 'how', 'long', 'is', 'forever', 'white', 'rabbit', 'sometimes', 'just', 'one', 'second']
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> text2words('"Alice: "How long is forever?"\n\nWhite Rabbit: "Sometimes, just one second."\n')
          ['alice', 'how', 'long', 'is', 'forever', 'white', 'rabbit', 'sometimes', 'just', 'one', 'second']
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> text2words('"Alice: "How long is forever? ? ?"\nWhite Rabbit: "Sometimes, just one second..."\n')
          ['alice', 'how', 'long', 'is', 'forever', 'white', 'rabbit', 'sometimes', 'just', 'one', 'second']
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
