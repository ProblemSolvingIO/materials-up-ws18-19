test = {
  'name': 'Question 4.7',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> 0 <= accuracy <= 1
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
