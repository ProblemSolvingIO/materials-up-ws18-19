from pathlib import Path


def read_text(filename):
    with open(filename) as fh:
        return fh.read()


def known_author_signatures():
    return dict(read_signature(filename) for filename in Path("signatures/").iterdir())


def read_signature(filename):
    with open(filename) as fh:
        author, *signature = [l.strip() for l in fh]
    return author, [float(val) for val in select_relevant_features(signature)]


def select_relevant_features(signature):
    return signature[:3]
