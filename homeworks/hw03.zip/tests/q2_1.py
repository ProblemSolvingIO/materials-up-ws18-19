test = {
  'name': 'Question 1',
  'points': 3,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> sorted(generate_word_ngram('sm_doc_set/abf0704.txt', 1))[:5]
          [('$10,',), ('(except',), ('1930Õs,',), ('1945',), ('1948.',)]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> sorted(generate_word_ngram('sm_doc_set/abf0704.txt', 2))[:5]
          [('$10,', 'Canadians'), ('(except', 'proles),'), ('1930Õs,', 'to'), ('1945', 'and'), ('1948.', 'Orwell')]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> sorted(generate_word_ngram('sm_doc_set/abf0704.txt', 6))[:3]
          [('$10,', 'Canadians', 'remit', 'us', 'dollars.', 'Big'), ('(except', 'proles),', 'every', 'street,', 'wall,', 'and'), ('1930Õs,', 'to', 'the', 'ignorance', 'of', 'the')]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
