test = {
  'name': 'Question 4.1',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> len(likely_plagiarism)
          8
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> [score for (docs, score) in likely_plagiarism]
          [3216, 1061, 1048, 768, 756, 622, 573, 319]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': ">>> likely_plagiarism = catch_plagiarism('sm_doc_set/', 6, 200)",
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
