test = {
  'name': 'Question 4.1',
  'points': 5,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> len(likely_plagiarism)
          3
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> [score for (docs, score) in likely_plagiarism]
          [768, 622, 573]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': ">>> likely_plagiarism = catch_plagiarism('med_doc_set/', 6, 200)",
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
